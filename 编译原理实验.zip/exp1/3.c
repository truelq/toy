int fibo(int a){
	int a
	int b
	if(a==1 a==2){
		return 1
	}
}
