int a,,b
int a,,
int ,,a
if ( a )
{
	int a
}
