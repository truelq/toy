int main(){
    int a,b,c,d;
    
    float ee;
    a=12;
    ee=12.3;
    a++;
    ++b;
    c--;
    --d;
    a+=b;
    b*=c;
}
int b();