int fibo(int a){
	int a
	int b
	a=a-+b
	a,=a
	a+,=-a
	int b
}
