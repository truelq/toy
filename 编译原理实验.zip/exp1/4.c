int fibo(int a){
	int a
	int b
	a,=a
	if(a==1||a==2){
		return 1
	}
	return fibo(a-1)+fibo(a-2)
}
