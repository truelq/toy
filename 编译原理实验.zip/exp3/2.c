int main(){
	int m,n
	int i=1
	while(i<=m)
	{
		n=fibo(i)
		putchar('1')
		break
	}
	return 1
}
