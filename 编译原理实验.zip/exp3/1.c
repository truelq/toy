int _a,b,c
char kkk
float ttt
int test(int a,int b){
	int d=a+b+c
	d=a
	d=a
	return c
}
