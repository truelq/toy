int _a,b,c
int main(){
	int m,n
	int i=1
	while(i<=2)
	{
        int i=3
        if(i<=2)
        {
            putchar('1')
        }
		putchar('1')
		break
	}
	return 1
}
