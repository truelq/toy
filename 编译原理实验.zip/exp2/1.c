int _a,b,c//主要检测重复定义
float m,n
int c//外部重复定义
int test(int a,int a)//参数重复定义
int fibo(int a){
	int a
	c=c
	if(a==1||a==2)
	{
		return 1
	}
	return fibo(a-1)+fibo(a-2)
}
int fibo(int a){
	int a
	c=c
	if(a==1||a==2)
	{
		return 1
	}
	return fibo(a-1)+fibo(a-2)
}
