int a,b,c
int fibo(int a){
	int c
	if(a==1||a==2)
	{
		return 1
	}
	return fibo(a-1)+fibo(a-2)
}
int main(){
	int m,n,i
    char k
	i=1
	fibo(k)
	return 1
}
