int _a,b
int fibo(int a){
	int c=b
    c=c
	if(a==1||a==2)
	{
		e=e
		{
			int e
			b=e
		}
		{
			e=e
		}
		return 1
	}
	return fibo(a-1)+fibo(a-2)
}
int main(){
	int m,n,i
	m=read()
	i=1
	while(i<=m)
	{
		n=fibo(i)
		write(n)
		break
	}
	m=m+n*i+i
	i+=1
	++i
	m=2.333
	d='c'
	return 1
}
